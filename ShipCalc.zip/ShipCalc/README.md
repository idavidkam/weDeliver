Android app for managing shipments
