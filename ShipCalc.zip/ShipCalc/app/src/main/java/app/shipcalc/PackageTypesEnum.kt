package app.shipcalc

enum class PackageTypesEnum {
    ENVELOPE, SMALL_PACKAGE, LARG_PACKAGE
}